
public class EpamJunittaskTestLogic {

	public String removeAs(String inputString){
		String s=new String("");
		inputString = inputString.toUpperCase();
		if(inputString.charAt(0)=='A'&&inputString.charAt(1)=='A') {
			s=inputString.substring(2,inputString.length());
		}
		else if(inputString.charAt(0)=='A') {
			s=inputString.substring(1,inputString.length());
		}
		else if(inputString.charAt(1)=='A') {
			s+=inputString.charAt(0);
			s=inputString.substring(2,inputString.length());
		}
		else {
			s = inputString;
		}
		return s;
	}

}
