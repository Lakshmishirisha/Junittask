import static org.junit.Assert.*;
import org.junit.*;

public class EpamJunittask {
	
	EpamJunittaskTestLogic objec;
	
	@BeforeClass
	public static void before2() {
		System.out.println("Only once executed at starting");
	}
	
	@BeforeAll
	public void before1() {
		objec = new EpamJunittaskTestLogic();
	}
	
	@Test
	public void test1() {
		objec = new EpamJunittaskTestLogic();
		assertEquals("BCD", objec.removeAs(("ABCD")));
	}
	
	public void test2() {
		 assertEquals("CD", objec.removeAs(("AACD")));
	}
	
	public void test3() {
		 assertEquals("BCD", objec.removeAs(("BACD")));
	}
	
	public void test4() {
		 assertEquals("BBAA", objec.removeAs(("BBAA")));
	}
	
	public void test5() {
		 assertEquals("BAA", objec.removeAs(("AABAA")));
	}
	
	public void test6() {
		 assertEquals("", objec.removeAs(("AA")));
	}
	
	public void test7() {
		 assertEquals("", objec.removeAs(("A")));
	}
}
