
public @interface BeforeAll {

}
